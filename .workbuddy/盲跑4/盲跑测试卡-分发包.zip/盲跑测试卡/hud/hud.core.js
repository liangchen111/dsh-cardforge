/* ============================================================================
 * 盲跑测试卡 HUD —— 一张卡最小但能跑起来的界面层
 *
 * 它不含任何世界观内容，做的是四件事：
 *   ① 把宿主（ElecKoi）的接口包一层，读得到变量、写得回变量；
 *   ② 把变量树原样渲染成一块面板（你加变量，面板上就多一行，不用改代码）；
 *   ③ 一间建卡器 —— 把「玩家」那份档案填成表单，封缄即写回变量；
 *   ④ 一颗常驻悬浮球（可拖拽，点开就是那块面板）；
 *   ⑤ 一个接线口，给「选着接」的模块（骰子框、尺度说明……见 hud/模块/）。
 *
 * 三个视图共用这一份代码，靠页面上的 data-view 认领：
 *   data-view="create"  → 建卡器（只在开场那一条消息里）
 *   data-view="card"    → 面板（每轮回复末尾）
 *
 * 改内容改 source/*.spec.yaml；改样子改 hud.css；改这里 = 改机制。
 * ========================================================================== */
(function () {
  'use strict';

  /* ---------------------------------------------------------------- 配置 */

  var CONFIG = {
    /* 变量树里那两个顶层对象的键名 */
    playerObject: '玩家',
    worldObject: '世界设定',
    /* 备份模块**过夜**的那个位子：变量树里一个「给机器用的」对象，里面一格文本。
       它跟玩家档案住在同一套变量系统里，所以也是按会话存的 —— 重启软件、关掉这段
       对话再回来都还在；新开一段对话是另一局，那里自然是空的（这正是我们要的）。
       **跨局那一半不在这儿**：备份模块自己再压一份到宿主窗口的 localStorage
       （按机器存，钥匙由模块的 FORMAT 派生），本局这一格空着时「从存档取回」退到它。
       模块不写死这两个名字，照这里现读 —— 想把那格叫别的，改这一行就够。
       没接备份模块时它一直空着，面板上只会显示一行「机器位」。 */
    archiveObject: '存档',
    archiveSlot: '角色',
    /* 玩家侧的两个档位 */
    scaleKey: '叙事尺度',
    scaleValues: ['克制', '标准', '放开'],
    pressureKey: '压力源',
    /* 建卡器上出现的字段；加一行就多一栏，不用动别处。
       type: text / number / list（list = 一行一件，写回是数组） */
    fields: [
      { key: '姓名', label: '姓名', type: 'text', hint: '写你在这个世界里用的名字' },
      { key: '性别', label: '性别', type: 'text', hint: '不填也行' },
      { key: '种族', label: '种族', type: 'text', hint: '你生来是什么' },
      { key: '等级', label: '等级', type: 'number', min: 1, max: 20, hint: '1 到 20' },
      { key: '状态', label: '状态', type: 'text', hint: '开场时是什么情形' },
      { key: '钱币', label: '钱币', type: 'number', min: 0, max: 9999999, hint: '身上的钱' },
      { key: '背包', label: '背包', type: 'list', hint: '一件一行' }
    ],
    /* 写回变量后，替玩家放进输入框里的一句话（只填不送，见 submit） */
    openingAsk: '我已经写好了自己的角色，请开场。'
  };

  /* 变量初值 —— 必须与 spec 的 initial_state 一致；
     这里是运行时兜底：宿主还没初始化时，界面也该画得出东西。
     「存档」那一格也要在这儿占位：fillState 会把初值里没有的对象原样留着不假，
     但面板要靠它才画得出「机器位」那一行。 */
  var DEFAULTS = {
    世界设定: { 压力源: false, 叙事尺度: '标准' },
    玩家: { 姓名: '', 性别: '', 种族: '', 等级: 1, 状态: '正常', 钱币: 0, 背包: [] },
    存档: { 角色: '' }
  };

  /* ---------------------------------------------------------------- 小工具 */

  function $(sel, root) { return (root || document).querySelector(sel); }

  function each(sel, fn, root) {
    var list = (root || document).querySelectorAll(sel);
    for (var i = 0; i < list.length; i++) fn(list[i], i);
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function str(v) { return String(v == null ? '' : v).trim(); }

  function num(v, fallback) {
    var n = typeof v === 'number' ? v : parseFloat(str(v));
    return isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }

  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

  function isArr(v) { return Object.prototype.toString.call(v) === '[object Array]'; }

  function plain(v) { return v && typeof v === 'object' && !isArr(v) ? v : null; }

  function msgOf(err) { return (err && err.message) ? err.message : String(err); }

  function safeText(node, text) { if (node) node.textContent = text == null ? '' : String(text); }

  /* 把「一行一件」的文本切成数组；空白行丢掉，首尾空格去掉 */
  function parseList(text) {
    var lines = String(text == null ? '' : text).split(/\r?\n/);
    var out = [];
    for (var i = 0; i < lines.length; i++) {
      var s = str(lines[i]);
      if (s) out.push(s);
    }
    return out;
  }

  /* 数组 -> 一行一件的文本（写进 textarea 用） */
  function joinList(arr) {
    if (!isArr(arr)) return arr == null || arr === '' ? '' : String(arr);
    var out = [];
    for (var i = 0; i < arr.length; i++) out.push(String(arr[i] == null ? '' : arr[i]));
    return out.join('\n');
  }

  /* ------------------------------------------------------------ ElecKoi 桥 */

  function api() { return (typeof window !== 'undefined' && window.ElecKoi) || null; }

  /* 宿主的运行时是注入进来的，通常要等一两个 tick */
  function whenReady(cb, tries) {
    var left = tries == null ? 60 : tries;
    if (api()) { cb(api()); return; }
    if (left <= 0) { cb(null); return; }
    setTimeout(function () { whenReady(cb, left - 1); }, 50);
  }

  /* 传数组 = 按位置参数调；传对象 = 按请求体调。
     SDK 里 getState(options) 收对象，setState(state) / input.set(text) 收位置参数。 */
  function call(method, params) {
    var e = api();
    if (!e) return Promise.reject(new Error('ElecKoi 运行时不可用'));
    var parts = String(method).split('.');
    var fn = e;
    for (var i = 0; i < parts.length; i++) fn = fn && fn[parts[i]];
    if (typeof fn !== 'function') return Promise.reject(new Error('缺少接口：' + method));
    try {
      var self = e;
      for (var j = 0; j < parts.length - 1; j++) self = self[parts[j]];
      var out = isArr(params) ? fn.apply(self, params) : fn.call(self, params || {});
      return Promise.resolve(out);
    } catch (err) {
      return Promise.reject(err);
    }
  }

  function readState() {
    return new Promise(function (resolve) {
      var e = api();
      if (!e || !e.variables || typeof e.variables.getState !== 'function') { resolve({}); return; }
      Promise.resolve(e.variables.getState({})).then(function (state) {
        resolve(plain(state) || {});
      }).catch(function () { resolve({}); });
    });
  }

  /* 变量树真正住的地方是 stat_data；万一宿主这一版摊平在顶层，就退到顶层同名键。 */
  function statOf(state) {
    var stat = plain(state && state.stat_data);
    return stat || plain(state) || {};
  }

  function objectOf(state, name) {
    var stat = statOf(state);
    var obj = plain(stat[name]);
    if (!obj) {
      var flat = plain(state && state[name]);
      if (flat) obj = flat;
    }
    return obj || {};
  }

  /* 读「存档」那一格 —— 备份模块过夜的地方。
     没接那个模块、或者这一局还没存过，读到的就是空串。
     写它不用另开口子：writeObject(CONFIG.archiveObject, ...) 就是那条路，
     自己拼一份 setState 出来只会多一处会写错的地方。 */
  function readArchive(state) {
    return str(objectOf(state, CONFIG.archiveObject)[CONFIG.archiveSlot]);
  }

  /* 读到的照搬，缺的键用初值补上 —— 界面上就不会出现 undefined */
  function fillState(stat) {
    var out = {}, src = plain(stat) || {};
    Object.keys(src).forEach(function (k) { out[k] = src[k]; });
    Object.keys(DEFAULTS).forEach(function (k) {
      var d = plain(DEFAULTS[k]);
      if (!d) { if (!(k in out)) out[k] = DEFAULTS[k]; return; }
      var merged = {}, got = plain(out[k]);
      Object.keys(d).forEach(function (kk) { merged[kk] = d[kk]; });
      if (got) Object.keys(got).forEach(function (kk) { merged[kk] = got[kk]; });
      out[k] = merged;
    });
    return out;
  }

  /* 写回一个人物对象里的若干键。
     顶层与 stat_data 两份都写：读的时候 stat_data 优先，只写顶层会「写了没反应」。
     写完读回核对，认不出来的值如实说出来，不假装成功。 */
  function writeObject(objectName, patch, scope) {
    var scopeName = scope || document;
    return readState().then(function (state) {
      var next = {};
      Object.keys(state || {}).forEach(function (k) { next[k] = state[k]; });
      var box = {}, src = objectOf(state, objectName);
      Object.keys(src).forEach(function (k) { box[k] = src[k]; });
      Object.keys(patch || {}).forEach(function (k) { box[k] = patch[k]; });
      next[objectName] = box;
      if (plain(next.stat_data)) {
        next.stat_data = fillState(next.stat_data);
        next.stat_data[objectName] = box;
      }
      return call('variables.setState', [next]);
    }).then(function () {
      return readState();
    }).then(function (back) {
      var got = objectOf(back, objectName);
      var bad = [];
      Object.keys(patch || {}).forEach(function (k) {
        if (JSON.stringify(got[k]) !== JSON.stringify(patch[k])) bad.push(k);
      });
      if (!bad.length) return '';
      return '注意：' + bad.join('、') + ' 没落进变量（可能被 Zod 挡回来了）。' +
        '可以去变量面板手动改。';
    });
  }

  /* 档位：只认配置里那三档，别的一律按中间那一档算 —— 不把怪值摆到界面上 */
  function scaleOf(state) {
    var v = str(objectOf(state, CONFIG.worldObject)[CONFIG.scaleKey]);
    return CONFIG.scaleValues.indexOf(v) < 0 ? CONFIG.scaleValues[1] : v;
  }

  function nextScale(v) {
    var i = CONFIG.scaleValues.indexOf(str(v));
    if (i < 0) i = 1;
    return CONFIG.scaleValues[(i + 1) % CONFIG.scaleValues.length];
  }

  function pressureOn(state) {
    var v = objectOf(state, CONFIG.worldObject)[CONFIG.pressureKey];
    if (typeof v === 'boolean') return v;
    return str(v) === 'true';
  }

  /* -------------------------------------------------------------- 渲染小件 */

  function valueHtml(v) {
    if (isArr(v)) {
      if (!v.length) return '<span class="hud-dim">空</span>';
      var out = [];
      for (var i = 0; i < v.length; i++) out.push('<span class="hud-tag">' + esc(v[i]) + '</span>');
      return out.join('');
    }
    if (typeof v === 'boolean') {
      return '<span class="hud-tag' + (v ? ' is-on' : '') + '">' + (v ? '开' : '关') + '</span>';
    }
    if (v === '' || v == null) return '<span class="hud-dim">—</span>';
    if (typeof v === 'object') return '<span class="hud-dim">（嵌套对象）</span>';
    return esc(v);
  }

  function rowHtml(label, v) {
    return '<div class="hud-row"><span class="hud-row__k">' + esc(label) +
      '</span><span class="hud-row__v">' + valueHtml(v) + '</span></div>';
  }

  /* 一层对象 -> 若干行；值本身是对象就递归成一小节 */
  function objectRows(obj, depth) {
    var out = [];
    Object.keys(obj || {}).forEach(function (k) {
      var v = obj[k];
      if (plain(v) && Object.keys(v).length) {
        out.push('<div class="hud-sub' + (depth ? ' hud-sub--deep' : '') +
          '"><div class="hud-sub__t">' + esc(k) + '</div>' +
          objectRows(v, (depth || 0) + 1).join('') + '</div>');
      } else {
        out.push(rowHtml(k, v));
      }
    });
    return out;
  }

  /* 整棵变量树 -> 面板主体。你往 spec 里加变量，这里就多一行，不用改代码。 */
  function panelHtml(state) {
    var stat = fillState(statOf(state));
    var keys = Object.keys(stat);
    if (!keys.length) return '<div class="hud-empty">还没有变量。</div>';
    var out = [];
    for (var i = 0; i < keys.length; i++) {
      var name = keys[i], obj = stat[name];
      out.push('<section class="hud-sec">');
      out.push('<div class="hud-sec__h">' + esc(name) + '</div>');
      /* 「存档」那一格是机器位：里面装的是一整份备份（几百上千字的一段 JSON），
         摊在面板上只会把别的都挤没。它是给机器用的，说清有没有就够了 ——
         要看内容去建卡器那一页，或者去宿主自己的变量面板。 */
      if (name === CONFIG.archiveObject) {
        out.push('<div class="hud-dim">' +
          (readArchive(state) ? '（机器位 · 存着一份备份）' : '（机器位 · 空）') + '</div>');
        out.push('</section>');
        continue;
      }
      if (plain(obj)) {
        out.push(objectRows(obj).join('') || '<div class="hud-dim">（空）</div>');
      } else {
        out.push(rowHtml(name, obj));
      }
      out.push('</section>');
    }
    return out.join('') + moduleBlocks('panel', state);
  }

  /* 一行摘要：谁、几级、身上什么情形。面板折起来时看这一行就够。 */
  function briefOf(state) {
    var p = objectOf(state, CONFIG.playerObject);
    var bits = [];
    if (str(p['姓名'])) bits.push(str(p['姓名']));
    if (str(p['种族'])) bits.push(str(p['种族']));
    if (str(p['等级']) !== '') bits.push('等级 ' + num(p['等级'], 1));
    if (str(p['状态']) && str(p['状态']) !== '正常') bits.push(str(p['状态']));
    return bits.length ? bits.join(' · ') : '尚无角色档案';
  }

  function hasProfile(state) {
    var p = objectOf(state, CONFIG.playerObject);
    return !!str(p['姓名']);
  }

  /* ---------------------------------------------------------------- 视图 */

  function sectionHtml(state) {
    return '' +
      '<div class="hud" data-hud>' +
      '  <div class="hud__head">' +
      '    <span class="hud__title">状态</span>' +
      '    <span class="hud__brief" data-brief>' + esc(briefOf(state)) + '</span>' +
      '    <button type="button" class="hud-btn hud-btn--quiet" data-act="fold">收起</button>' +
      '  </div>' +
      '  <div class="hud__body" data-body>' + panelHtml(state) + '</div>' +
      '  <div class="hud__note" data-note hidden></div>' +
      '</div>';
  }

  function renderCardView(root) {
    if (!root) return;
    root.innerHTML = sectionHtml({});
    bindCard(root);
    refresh(root);
  }

  function refresh(root) {
    return readState().then(function (state) {
      var box = $('[data-body]', root);
      if (box) box.innerHTML = panelHtml(state);
      safeText($('[data-brief]', root), briefOf(state));
      return state;
    });
  }

  function noteIn(root, text, kind) {
    var n = $('[data-note]', root);
    if (!n) return;
    n.hidden = !text;
    n.className = 'hud__note' + (kind ? ' ' + kind : '');
    n.textContent = text || '';
  }

  function bindCard(root) {
    root.addEventListener('click', function (ev) {
      var t = ev.target;
      while (t && t !== root && !t.getAttribute('data-act')) t = t.parentNode;
      if (!t || t === root) return;
      var act = t.getAttribute('data-act');
      if (act === 'fold') {
        var hud = $('[data-hud]', root);
        if (!hud) return;
        var folded = hud.className.indexOf('is-fold') >= 0;
        hud.className = folded ? 'hud' : 'hud is-fold';
        t.textContent = folded ? '收起' : '展开';
      } else if (act === 'refresh') {
        refresh(root).then(function () { noteIn(root, ''); });
      }
    });
  }

  /* -------------------------------------------------------------- 建卡器 */

  function fieldControl(f, p) {
    var attrs = ' data-field="' + esc(f.key) + '" data-type="' + esc(f.type) + '"';
    if (f.type === 'list') {
      return '<label class="hud-field hud-field--wide"><span class="hud-field__l">' +
        esc(f.label) + '</span><textarea class="hud-input hud-input--area" rows="3"' + attrs +
        ' placeholder="' + esc(f.hint || '') + '">' + esc(joinList(p[f.key])) + '</textarea></label>';
    }
    var type = f.type === 'number' ? 'number' : 'text';
    var extra = '';
    if (f.type === 'number') {
      if (f.min != null) extra += ' min="' + f.min + '"';
      if (f.max != null) extra += ' max="' + f.max + '"';
      extra += ' step="1"';
    }
    return '<label class="hud-field"><span class="hud-field__l">' + esc(f.label) +
      '</span><input class="hud-input" type="' + type + '"' + attrs + extra +
      ' value="' + esc(p[f.key] == null ? '' : p[f.key]) + '" placeholder="' +
      esc(f.hint || '') + '"' + '></label>';
  }

  function createHtml(state) {
    var p = objectOf(state, CONFIG.playerObject);
    var on = pressureOn(state);
    var scale = scaleOf(state);
    var controls = [];
    for (var i = 0; i < CONFIG.fields.length; i++) controls.push(fieldControl(CONFIG.fields[i], p));
    return '' +
      '<div class="hud hud--create" data-create>' +
      '  <div class="hud__head">' +
      '    <span class="hud__title">写一个自己</span>' +
      '    <span class="hud__brief">填完点「封缄 · 开始」</span>' +
      '  </div>' +
      '  <div class="hud__grid">' + controls.join('') + '</div>' +
      '  <div class="hud__row">' +
      '    <button type="button" class="hud-btn hud-btn--quiet" data-act="scale">叙事尺度：' +
      esc(scale) + '</button>' +
      '    <button type="button" class="hud-btn hud-btn--quiet" data-act="pressure">时局压力：' +
      (on ? '开' : '关') + '</button>' +
      '  </div>' +
      moduleBlocks('create', state) +
      '  <div class="hud__foot">' +
      '    <button type="button" class="hud-btn hud-btn--main" data-act="submit">封缄 · 开始</button>' +
      '    <button type="button" class="hud-btn hud-btn--quiet" data-act="reset">清空</button>' +
      '  </div>' +
      '  <div class="hud__note" data-note hidden></div>' +
      '</div>';
  }

  function renderCreateView(root) {
    if (!root) return;
    /* 只绑一次：监听挂在 root 上，后面的重画换的是 root 里的内容，不动这个监听 */
    bindCreate(root);
    root.innerHTML = createHtml({});
    readState().then(function (state) {
      /* 读变量是异步的，回来时玩家可能已经动手填了 —— 动过就不覆盖，别把人写的字吃掉 */
      if (touched(root)) return;
      root.innerHTML = createHtml(state);
    });
  }

  /* 表单里有没有人填过东西 */
  function touched(root) {
    var got = readCreateForm(root);
    var any = false;
    Object.keys(got).forEach(function (k) {
      var v = got[k];
      if (isArr(v) ? v.length > 0 : str(v) !== '') any = true;
    });
    return any;
  }

  function readCreateForm(root) {
    var out = {};
    each('[data-field]', function (el) {
      var key = el.getAttribute('data-field');
      var type = el.getAttribute('data-type');
      if (type === 'list') out[key] = parseList(el.value);
      else if (type === 'number') {
        var min = el.getAttribute('min'), max = el.getAttribute('max');
        var v = Math.round(num(el.value, 0));
        out[key] = clamp(v, num(min, v), num(max, v));
      } else out[key] = str(el.value);
    }, root);
    return out;
  }

  /* 封缄 = 把表单写回变量。
     默认走 input.set（只填不送）：把请求放进输入框、由玩家自己按发送，
     这样不会有人替你把对话视口搬走 —— 建卡器就长在对话的那一楼里。

     写完（成不成都在）之后叫一次模块的 afterSubmit：「备份」要在这一刻
     把整份草稿与刚写进去的档案一起存进那个过夜的地方。 */
  function submit(root) {
    var patch = readCreateForm(root);
    noteIn(root, '正在封缄…');
    return writeObject(CONFIG.playerObject, patch, root).then(function (warn) {
      afterSubmit(root, warn);
      var e = api();
      if (e && e.input && typeof e.input.set === 'function') {
        return call('input.set', [CONFIG.openingAsk]).then(function () {
          noteIn(root, warn ? warn : '已写入变量，并把开场请求填进了输入框 —— 确认后按发送。',
            warn ? 'is-error' : 'is-ok');
        });
      }
      noteIn(root, warn ? warn : '已写入变量。', warn ? 'is-error' : 'is-ok');
    }).catch(function (err) {
      noteIn(root, '写入失败：' + msgOf(err), 'is-error');
    });
  }

  function bindCreate(root) {
    root.addEventListener('click', function (ev) {
      var t = ev.target;
      while (t && t !== root && !t.getAttribute('data-act')) t = t.parentNode;
      if (!t || t === root) return;
      var act = t.getAttribute('data-act');
      if (act === 'submit') { submit(root); return; }
      if (act === 'reset') {
        each('[data-field]', function (el) { el.value = ''; }, root);
        noteIn(root, '已清空（变量没动）。');
        return;
      }
      if (act === 'scale') {
        var next = nextScale(t.getAttribute('data-scale') || t.textContent.replace(/^.*：/, ''));
        t.setAttribute('data-scale', next);
        safeText(t, '叙事尺度：' + next);
        writeScale(next, root).then(function (r) {
          noteIn(root, r.warn || ('叙事尺度已拨到「' + r.value +
            '」—— 这一档是什么意思，本卡不解释，由你的预设决定。'),
            r.warn ? 'is-error' : 'is-ok');
        });
        return;
      }
      if (act === 'pressure') {
        var on = t.textContent.indexOf('开') >= 0;
        var nextOn = !on;
        safeText(t, '时局压力：' + (nextOn ? '开' : '关'));
        writeObject(CONFIG.worldObject, mkPatch(CONFIG.pressureKey, nextOn), root).then(function (warn) {
          noteIn(root, warn || ('时局压力已拨到「' + (nextOn ? '开' : '关') + '」。'),
            warn ? 'is-error' : 'is-ok');
        });
        return;
      }
    });
  }

  /* 对象字面量里用变量当键名，得这样绕一下（ES5 没有计算属性） */
  function mkPatch(key, value) {
    var o = {};
    o[key] = value;
    return o;
  }

  /* 拨一档：册上没有的值一律按中间那一档算，认不出的值不往外写 */
  function writeScale(v, scope) {
    var val = str(v);
    if (CONFIG.scaleValues.indexOf(val) < 0) val = CONFIG.scaleValues[1];
    return writeObject(CONFIG.worldObject, mkPatch(CONFIG.scaleKey, val), scope)
      .then(function (warn) { return { value: val, warn: warn }; });
  }

  /* -------------------------------------------------------------- 悬浮球 */

  var BALL_KEY = 'card97aa90-hud-ball';

  function loadBallPos() {
    try {
      var raw = window.localStorage && window.localStorage.getItem(BALL_KEY);
      if (!raw) return null;
      var p = JSON.parse(raw);
      return (p && typeof p.x === 'number' && typeof p.y === 'number') ? p : null;
    } catch (e) { return null; }
  }

  function saveBallPos(x, y) {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(BALL_KEY, JSON.stringify({ x: x, y: y }));
      }
    } catch (e) { /* 存不了就算了，位置不记住不影响用 */ }
  }

  /* 球挂在宿主文档里：跟「这一页渲染哪个视图」无关，只要这一页渲染出了东西就该有球 */
  function mountBall(holder, targetDoc) {
    var doc = targetDoc || (holder && holder.ownerDocument) || document;
    if (!doc || !doc.body) return null;
    if (doc.querySelector('[data-ball]')) return doc.querySelector('[data-ball]');

    var ball = doc.createElement('div');
    ball.className = 'hud-ball';
    ball.setAttribute('data-ball', '');
    ball.textContent = '状';
    doc.body.appendChild(ball);

    var panel = doc.createElement('div');
    panel.className = 'hud-ballpanel';
    panel.setAttribute('data-ballpanel', '');
    panel.hidden = true;
    doc.body.appendChild(panel);

    var pos = loadBallPos() || { x: 18, y: Math.max(18, (doc.defaultView.innerHeight || 700) - 120) };
    place(ball, pos.x, pos.y);

    function place(el, x, y) {
      var w = doc.defaultView.innerWidth || 800, h = doc.defaultView.innerHeight || 700;
      var bx = clamp(x, 4, Math.max(4, w - 52));
      var by = clamp(y, 4, Math.max(4, h - 52));
      el.style.left = bx + 'px';
      el.style.top = by + 'px';
      el.style.bottom = 'auto';
      el.style.right = 'auto';
    }

    var dragging = false, moved = false, sx = 0, sy = 0, ox = 0, oy = 0;

    function down(ev) {
      var p = pointOf(ev);
      dragging = true; moved = false;
      sx = p.x; sy = p.y;
      var r = ball.getBoundingClientRect();
      ox = r.left; oy = r.top;
      ev.preventDefault();
    }

    function move(ev) {
      if (!dragging) return;
      var p = pointOf(ev);
      var dx = p.x - sx, dy = p.y - sy;
      if (Math.abs(dx) + Math.abs(dy) > 3) moved = true;
      place(ball, ox + dx, oy + dy);
      if (!panel.hidden) place(panel, ox + dx - 268, oy + dy - 8);
      ev.preventDefault();
    }

    function up() {
      if (!dragging) return;
      dragging = false;
      if (moved) {
        var r = ball.getBoundingClientRect();
        saveBallPos(r.left, r.top);
      } else {
        toggle();
      }
    }

    function pointOf(ev) {
      var t = ev.touches && ev.touches[0] ? ev.touches[0] : ev;
      return { x: t.clientX, y: t.clientY };
    }

    function toggle() {
      panel.hidden = !panel.hidden;
      if (panel.hidden) return;
      var r = ball.getBoundingClientRect();
      panel.innerHTML = '<div class="hud-ballpanel__t">状态</div>' +
        '<div class="hud-ballpanel__b" data-ball-body>正在读取…</div>';
      place(panel, r.left - 268, r.top - 8);
      readState().then(function (state) {
        var b = panel.querySelector('[data-ball-body]');
        if (b) b.innerHTML = hasProfile(state) ? panelHtml(state) :
          '<div class="hud-dim">还没有角色档案。</div>';
      });
    }

    ball.addEventListener('mousedown', down);
    ball.addEventListener('touchstart', down, { passive: false });
    doc.addEventListener('mousemove', move);
    doc.addEventListener('touchmove', move, { passive: false });
    doc.addEventListener('mouseup', up);
    doc.addEventListener('touchend', up);

    return ball;
  }

  /* ------------------------------------------------------------ 可选模块

     模块 = 一张卡按需接的能力（骰子框、尺度说明、档案备份、AI 代笔……）。
     它们的代码不写在上面，而是各占 hud/模块/<名>/<名>.js 一个文件
     （一个模块一个目录，与 build_hud.py 找的是同一个形状），
     由 hud/build_hud.py 按 hud.conf.json 的「模块」列表拼进同一页、
     拼在核心之后。不接就不拼 —— 页面上不会多一个字节。

     模块脚本是**另一段独立代码**：它进不到这个 IIFE 里面来（这里的东西
     不外露），所以接线走注册表 —— 模块把自己的名字与挂载点交给 useModule()。

     一个模块最多给四样，能给几样给几样，没给的那处就不接：

       · create(state) → 一段 HTML，接在建卡器的档位行之后
       · panel(state)  → 一段 HTML，接在面板最底下
       · mount(hud)    → 页面就绪后自己动手（要绑事件、要常驻的走这条；
                         hud 是下面那份导出，够它读变量、写变量、拿配置）
       · afterSubmit(hud, root, warn) → 封缄那一笔写落定之后叫一次
                         （root 是建卡器那一块，warn 是那笔写有没有被挡回来）

     四处调用都包了 try：模块里抛出来的异常只让它自己那一块不出现，
     面板其余部分照常 —— 一个模块坏了不该把整页拖垮。 */
  var MODULES = [];
  var booted = false;

  function useModule(m) {
    if (!m || typeof m !== 'object' || !str(m.name)) return false;
    for (var i = 0; i < MODULES.length; i++) {
      if (MODULES[i].name === m.name) return false;   /* 同一块不认识两遍 */
    }
    MODULES.push(m);
    /* 正常情形下模块脚本比 boot 早（同一页里跟在后面的那一段，boot 还压在
       DOMContentLoaded 上）。万一晚到，补画一次面板 —— 面板重画是幂等的；
       建卡器那一份是表单，重画会吃掉已经填进去的字，所以不补它。 */
    if (booted) each('[data-view="card"]', function (root) { refresh(root); });
    return true;
  }

  function moduleBlocks(kind, state) {
    var out = [];
    for (var i = 0; i < MODULES.length; i++) {
      var fn = MODULES[i][kind];
      if (typeof fn !== 'function') continue;
      try {
        var html = fn(state);
        if (html) out.push(html);
      } catch (e) { /* 模块自己那块画不出来，就少一块 */ }
    }
    return out.join('');
  }

  /* 封缄写完之后的挂载点（模块可以不给，不给就跳过）。
     传 root 是让模块还能读到表单里那几栏，warn 是那一笔写有没有被挡回来。
     **一定要在这一笔落定之后叫**：每一笔写都是「读出整份 → 改一处 → 整份写回」，
     模块若抢在它前面读一遍再写，就会把刚封缄的档案盖回旧值。 */
  function afterSubmit(root, warn) {
    for (var i = 0; i < MODULES.length; i++) {
      var fn = MODULES[i].afterSubmit;
      if (typeof fn !== 'function') continue;
      try { fn(window.CARD97AA90_HUD, root, warn); } catch (e) { /* 一个模块跟不上，不该拦住建卡 */ }
    }
  }

  /* ---------------------------------------------------------------- 导出 */

  window.CARD97AA90_HUD = {
    CONFIG: CONFIG,
    DEFAULTS: DEFAULTS,
    esc: esc,
    str: str,
    num: num,
    clamp: clamp,
    isArr: isArr,
    plain: plain,
    msgOf: msgOf,
    parseList: parseList,
    joinList: joinList,
    fillState: fillState,
    objectOf: objectOf,
    statOf: statOf,
    readArchive: readArchive,
    scaleOf: scaleOf,
    nextScale: nextScale,
    pressureOn: pressureOn,
    valueHtml: valueHtml,
    panelHtml: panelHtml,
    objectRows: objectRows,
    briefOf: briefOf,
    hasProfile: hasProfile,
    mkPatch: mkPatch,
    touched: touched,
    createHtml: createHtml,
    readCreateForm: readCreateForm,
    renderCardView: renderCardView,
    renderCreateView: renderCreateView,
    mountBall: mountBall,
    readState: readState,
    writeObject: writeObject,
    whenReady: whenReady,
    /* 宿主桥本身：有的模块要的不止「读变量 / 写变量」——
       代笔模块要用 input.set 把请求填进对话输入框、用 messages.list 认回话。
       桥只此一份，模块照这一份用；各写各的等于把同一件事做两遍。 */
    api: api,
    call: call,
    /* 模块接线口：模块脚本就靠这两个进到这一页里来 */
    useModule: useModule,
    modules: function () { return MODULES.slice(); }
  };

  /* ------------------------------------------------------------ 自动启动 */

  function boot() {
    booted = true;
    var createRoot = document.querySelector('[data-view="create"]');
    if (createRoot) renderCreateView(createRoot);
    var cardRoot = document.querySelector('[data-view="card"]');
    if (cardRoot) renderCardView(cardRoot);
    var holder = cardRoot || createRoot;
    if (holder) mountBall(holder);
    for (var i = 0; i < MODULES.length; i++) {
      if (typeof MODULES[i].mount !== 'function') continue;
      try { MODULES[i].mount(window.CARD97AA90_HUD); }
      catch (e) { /* 一个模块挂不上，别的照挂 */ }
    }
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', boot);
    } else {
      /* 已经过了 loading 也往后压一格：同一页里跟在后面的模块脚本还没跑，
         boot 早跑一步，模块就赶不上这一画。 */
      setTimeout(boot, 0);
    }
  }
})();
